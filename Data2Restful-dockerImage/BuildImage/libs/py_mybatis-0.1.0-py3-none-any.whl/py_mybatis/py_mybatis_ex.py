class PyMybatisEx(Exception):
    pass
