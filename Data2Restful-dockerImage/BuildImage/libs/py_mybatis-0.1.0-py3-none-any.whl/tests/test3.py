import xml.etree.ElementTree as ET

# 定义一个XML格式的字符串
xml_str = """
        SELECT name, category, price
        FROM fruits
        <trim prefix="WHERE" prefixOverrides="OR">
            <if test="'name' in params">
                OR name = #{name}
            </if>
        </trim>
"""

# 将字符串解析为XML元素
xml_element = ET.fromstring(xml_str)

# 打印XML元素

print(xml_element.text)
for next_child in xml_element:
    print(next_child)
