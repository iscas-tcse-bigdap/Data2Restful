import os
import unittest
from py_mybatis import PyMapper


base_dir = os.path.abspath(os.path.dirname(__file__))


class PyMybatisTest(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.mapper = PyMapper(xml_path='test2.xml')

    def test_trim(self):
        self.sql_id = 'testTrim'
        params = {'name': 'cat'}
        print("============{}============".format(self.sql_id))
        self.statement = self.mapper.statement(sql_id=self.sql_id, reindent=True,
                                               params=params)
        print(self.statement)


if __name__ == '__main__':
    unittest.main()
